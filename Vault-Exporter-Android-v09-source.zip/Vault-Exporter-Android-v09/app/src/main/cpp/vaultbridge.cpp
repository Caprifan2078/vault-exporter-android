#include <jni.h>
#include <dlfcn.h>
#include <mutex>
#include <string>
#include <cstdint>

// Runtime-link against OFFICIAL libtdjson.so, installed into APK jniLibs for each ABI.
// Do not load or ship modified/unknown third-party Telegram libraries.
static void* library = nullptr;
static int (*create_client)() = nullptr;
static void (*send_request)(int, const char*) = nullptr;
static const char* (*receive_result)(double) = nullptr;
static std::once_flag init_once;

static bool ready() {
  std::call_once(init_once, [] {
    library = dlopen("libtdjson.so", RTLD_NOW | RTLD_LOCAL);
    if (!library) return;
    create_client = (int (*)())dlsym(library, "td_create_client_id");
    send_request = (void (*)(int, const char*))dlsym(library, "td_send");
    receive_result = (const char* (*)(double))dlsym(library, "td_receive");
  });
  return library && create_client && send_request && receive_result;
}

extern "C" JNIEXPORT jlong JNICALL
Java_org_vault_exporter_TdNative_createClient(JNIEnv*, jclass) {
  if (!ready()) return 0;
  return create_client();
}
extern "C" JNIEXPORT void JNICALL
Java_org_vault_exporter_TdNative_send(JNIEnv* env, jclass, jlong client, jstring json) {
  if (!ready() || !json || client == 0) return;
  const char* bytes = env->GetStringUTFChars(json, nullptr);
  if (!bytes) return;
  send_request((int)client, bytes);
  env->ReleaseStringUTFChars(json, bytes);
}
extern "C" JNIEXPORT jstring JNICALL
Java_org_vault_exporter_TdNative_receive(JNIEnv* env, jclass, jdouble seconds) {
  if (!ready()) return nullptr;
  const char* response = receive_result(seconds);
  if (!response) return nullptr;
  // TDLib uses standard UTF-8, while JNI NewStringUTF expects modified UTF-8.
  // Convert explicitly to UTF-16 to preserve emoji and non-BMP code points.
  std::u16string decoded;
  const unsigned char *p = reinterpret_cast<const unsigned char*>(response);
  while (*p) {
    uint32_t c = 0;
    if (*p < 0x80) { c=*p++; }
    else if ((*p & 0xE0) == 0xC0 && (p[1] & 0xC0) == 0x80) {
      c=((p[0]&0x1F)<<6)|(p[1]&0x3F); p+=2;
      if (c<0x80) c=0xFFFD;
    } else if ((*p & 0xF0) == 0xE0 && p[1] && p[2] &&
          (p[1]&0xC0)==0x80 && (p[2]&0xC0)==0x80) {
      c=((p[0]&0x0F)<<12)|((p[1]&0x3F)<<6)|(p[2]&0x3F); p+=3;
      if(c<0x800 || (c>=0xD800 && c<=0xDFFF)) c=0xFFFD;
    } else if ((*p & 0xF8) == 0xF0 && p[1] && p[2] && p[3] &&
          (p[1]&0xC0)==0x80 && (p[2]&0xC0)==0x80 && (p[3]&0xC0)==0x80) {
      c=((p[0]&7)<<18)|((p[1]&0x3F)<<12)|((p[2]&0x3F)<<6)|(p[3]&0x3F); p+=4;
      if(c<0x10000 || c>0x10FFFF) c=0xFFFD;
    } else { c=0xFFFD; p++; }
    if (c<0x10000) decoded.push_back((char16_t)c);
    else { c-=0x10000; decoded.push_back((char16_t)(0xD800|(c>>10)));
      decoded.push_back((char16_t)(0xDC00|(c&0x3FF))); }
  }
  return env->NewString(reinterpret_cast<const jchar*>(decoded.data()), (jsize)decoded.size());
}
