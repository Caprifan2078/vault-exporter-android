package org.vault.exporter;

import org.json.JSONObject;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

public final class TdGateway {
  public interface Listener { void onUpdate(JSONObject event); }
  private final long client;
  private final ConcurrentHashMap<String, CompletableFuture<JSONObject>> pending = new ConcurrentHashMap<>();
  private final AtomicLong sequence = new AtomicLong();
  private final Listener listener;
  private final Thread reader;
  private volatile boolean running = true;

  public TdGateway(Listener callback) {
    this.listener = callback;
    client = TdNative.createClient();
    if (client == 0) throw new IllegalStateException("TDLib не включена в APK: нет официальной libtdjson.so");
    reader = new Thread(() -> {
      while (running) {
        String response = TdNative.receive(0.5);
        if (response == null) continue;
        try {
          JSONObject obj = new JSONObject(response);
          if (obj.optLong("@client_id", client) != client) continue;
          String extra = obj.optString("@extra", "");
          if (!extra.isEmpty()) {
            CompletableFuture<JSONObject> promise = pending.remove(extra);
            if (promise != null) { promise.complete(obj); continue; }
          }
          if (obj.optString("@type").startsWith("update")) listener.onUpdate(obj);
        } catch (Exception ignored) { /* Don't log private Telegram content. */ }
      }
    }, "tdlib-event-pump");
    reader.setDaemon(true);
    reader.start();
  }
  public CompletableFuture<JSONObject> call(JSONObject request) {
    if(!running)throw new IllegalStateException("TDLib client is closed");
    String id = Long.toString(sequence.incrementAndGet());
    CompletableFuture<JSONObject> result = new CompletableFuture<>();
    pending.put(id, result);
    try { request.put("@extra", id); TdNative.send(client, request.toString()); }
    catch (Exception e) { pending.remove(id); result.completeExceptionally(e); }
    return result;
  }
  public JSONObject await(JSONObject request, long timeoutSeconds) throws Exception {
    JSONObject response = call(request).get(timeoutSeconds, TimeUnit.SECONDS);
    if ("error".equals(response.optString("@type"))) {
      int code = response.optInt("code");
      String message = response.optString("message");
      long seconds = TelegramRateLimit.waitSeconds(code, message);
      if (seconds >= 0) throw new TelegramRateLimit.Delay(seconds);
      // Never include the serialized request or message contents in the exception.
      throw new IllegalStateException("Telegram отклонил запрос, код " + code + ". При повторной ошибке останови экспорт.");
    }
    return response;
  }
  public static JSONObject cmd(String name) {
    JSONObject req = new JSONObject();
    try { req.put("@type", name); } catch (Exception e) { throw new IllegalStateException(e); }
    return req;
  }
  public void stop() {
    if(!running)return;
    // Close the native client while preserving the separate TDLib authorization for restart.
    // This is NOT logOut: only the explicit button ends the Telegram account session.
    try{TdNative.send(client,"{\"@type\":\"close\"}");}catch(Throwable ignored){}
    running=false;
    for(CompletableFuture<JSONObject> v:pending.values())v.cancel(true);
    pending.clear();
    if(Thread.currentThread()!=reader){
      try{reader.join(1100);}catch(InterruptedException e){Thread.currentThread().interrupt();}
    }
  }
}
