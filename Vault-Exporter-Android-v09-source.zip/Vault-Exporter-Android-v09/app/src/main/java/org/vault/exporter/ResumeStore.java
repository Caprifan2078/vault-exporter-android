package org.vault.exporter;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Locale;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.Mac;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * App-private, encrypted, crash-recoverable staging area. No plaintext messages or media are
 * written to this store. Existing completed pages and media files are reusable after a restart.
 * The store's key is domain-separated from TDLib's database secret using HMAC-SHA256.
 * This code uses standard JVM APIs and can be tested without Android or a Telegram account.
 */
public final class ResumeStore implements Closeable {
  private static final byte[] MAGIC = "TVS1".getBytes(StandardCharsets.US_ASCII);
  private static final int MAX_PAGE_BYTES = 16 * 1024 * 1024;
  private final File root;
  private final byte[] key;
  private final long chatId;
  private final SecureRandom random = new SecureRandom();
  public static final class State {
    public final long chatId, cursor;
    public final int pages, messages, media;
    public final boolean historyFinished;
    public State(long chatId, long cursor, int pages, int messages, int media, boolean done) {
      this.chatId=chatId;this.cursor=cursor;this.pages=pages;this.messages=messages;this.media=media;this.historyFinished=done;
    }
  }
  public static final class Media {
    public final String sha256;
    public final long bytes;
    public Media(String sha, long bytes) { sha256=sha;this.bytes=bytes; }
  }
  public ResumeStore(File privateDir, long chatId, byte[] sessionSecret) throws Exception {
    if (chatId == 0 || sessionSecret == null || sessionSecret.length != 32) throw new IllegalArgumentException("Неправильный ключ или чат");
    this.chatId=chatId;
    this.root = new File(privateDir,"chat-"+chatId).getCanonicalFile();
    if (!root.isDirectory() && !root.mkdirs()) throw new IOException("Не удалось создать закрытый каталог");
    Mac mac = Mac.getInstance("HmacSHA256");
    mac.init(new SecretKeySpec(sessionSecret,"HmacSHA256"));
    this.key=mac.doFinal(("TelegramVault resume store v1|"+chatId).getBytes(StandardCharsets.UTF_8));
  }
  public State state() throws Exception {
    File state = path("checkpoint.enc");
    if (!state.exists()) return new State(chatId,0,0,0,0,false);
    try(DataInputStream in=new DataInputStream(open("checkpoint.enc"))) {
      if (in.readInt()!=0x52535431) throw new IOException("Неизвестный checkpoint");
      long cid=in.readLong(), cursor=in.readLong();
      int p=in.readInt(), m=in.readInt(), f=in.readInt(); boolean done=in.readBoolean();
      if(cid!=chatId || p<0 || m<0 || f<0 || (p>0 && cursor<=0)) throw new IOException("Повреждён checkpoint");
      if(in.read()!=-1) throw new IOException("Лишние байты checkpoint");
      return new State(cid,cursor,p,m,f,done);
    }
  }
  public void checkpoint(State state) throws Exception {
    if (state.chatId != chatId) throw new IllegalArgumentException("Другой чат");
    ByteArrayOutputStream out=new ByteArrayOutputStream();
    DataOutputStream data=new DataOutputStream(out);
    data.writeInt(0x52535431);data.writeLong(state.chatId);data.writeLong(state.cursor);
    data.writeInt(state.pages);data.writeInt(state.messages);data.writeInt(state.media);
    data.writeBoolean(state.historyFinished);data.close();
    put("checkpoint.enc",new ByteArrayInputStream(out.toByteArray()));
  }
  public void putPage(int page, byte[] messages, byte[] mediaIndex) throws Exception {
    if (page<1 || messages.length>MAX_PAGE_BYTES || mediaIndex.length>MAX_PAGE_BYTES)
      throw new IOException("Слишком большая страница сообщений");
    put(String.format(Locale.ROOT,"pages/%06d.jsonl.enc",page),new ByteArrayInputStream(messages));
    put(String.format(Locale.ROOT,"indexes/%06d.jsonl.enc",page),new ByteArrayInputStream(mediaIndex));
  }
  public Media saveMedia(long messageId,int fileId,File plaintext) throws Exception {
    String name=mediaName(messageId,fileId);
    if(exists(name)) return fingerprint(name); // authenticates the staged file, avoids re-download
    if(!plaintext.isFile()) throw new FileNotFoundException("Медиафайл отсутствует");
    if(root.getUsableSpace()<plaintext.length()+8L*1024*1024)
      throw new IOException("Недостаточно места для безопасного сохранения медиа");
    return put(name,new BufferedInputStream(new FileInputStream(plaintext)));
  }
  public boolean hasMedia(long messageId,int fileId) { return exists(mediaName(messageId,fileId)); }
  public Media mediaFingerprint(long messageId,int fileId) throws Exception { return fingerprint(mediaName(messageId,fileId)); }
  public InputStream openMedia(long messageId,int fileId) throws Exception { return open(mediaName(messageId,fileId)); }
  public InputStream openPage(int page) throws Exception { return open(String.format(Locale.ROOT,"pages/%06d.jsonl.enc",page)); }
  public InputStream openIndex(int page) throws Exception { return open(String.format(Locale.ROOT,"indexes/%06d.jsonl.enc",page)); }
  public boolean hasPage(int page) { return exists(String.format(Locale.ROOT,"pages/%06d.jsonl.enc",page)) && exists(String.format(Locale.ROOT,"indexes/%06d.jsonl.enc",page)); }
  private String mediaName(long messageId,int fileId) {
    if(messageId<=0 || fileId<=0) throw new IllegalArgumentException("Invalid media ID");
    return "media/"+messageId+"-"+fileId+".enc";
  }
  private boolean exists(String name) { return path(name).isFile(); }
  private File path(String name) {
    if(name.startsWith("/") || name.contains("..") || name.contains("\\") || name.indexOf('\0')!=-1)
      throw new IllegalArgumentException("Unsafe staging path");
    return new File(root,name);
  }
  private byte[] aad(String name) { return ("TVS1|"+chatId+"|"+name).getBytes(StandardCharsets.UTF_8); }
  private Media put(String name,InputStream input) throws Exception {
    File dest=path(name), parent=dest.getParentFile();
    if(!parent.isDirectory() && !parent.mkdirs()) throw new IOException("Не удалось создать папку checkpoint");
    File temp=File.createTempFile(".pending-",".tmp",parent);
    byte[] nonce=new byte[12]; random.nextBytes(nonce);
    MessageDigest md=MessageDigest.getInstance("SHA-256"); long size=0;
    try(InputStream src=input; FileOutputStream file=new FileOutputStream(temp)) {
      file.write(MAGIC);file.write(nonce);
      Cipher aes=Cipher.getInstance("AES/GCM/NoPadding");
      aes.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,nonce));
      aes.updateAAD(aad(name));
      // Do not close CipherOutputStream separately: it would close the underlying FileOutputStream.
      CipherOutputStream enc=new CipherOutputStream(file,aes);
      byte[] buf=new byte[65536];int n;
      while((n=src.read(buf))!=-1) {enc.write(buf,0,n);md.update(buf,0,n);size+=n;}
      enc.flush();enc.close(); // emits the authentication tag
      try(FileOutputStream fsync=new FileOutputStream(temp,true)) {fsync.getFD().sync();}
      if(!temp.renameTo(dest)) throw new IOException("Не удалось сохранить контрольную точку");
    } catch(Exception e) {temp.delete(); throw e;}
    return new Media(hex(md.digest()),size);
  }
  private InputStream open(String name) throws Exception {
    FileInputStream file=new FileInputStream(path(name));
    try {
      byte[] magic=new byte[4]; if(file.read(magic)!=4 || !Arrays.equals(magic,MAGIC)) throw new IOException("Неверный формат staging");
      byte[] nonce=new byte[12]; int off=0,n;
      while(off<nonce.length && (n=file.read(nonce,off,nonce.length-off))!=-1) off+=n;
      if(off<12) throw new EOFException("Обрезанный файл staging");
      Cipher aes=Cipher.getInstance("AES/GCM/NoPadding");
      aes.init(Cipher.DECRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,nonce));
      aes.updateAAD(aad(name));
      return new CipherInputStream(file,aes);
    } catch(Exception e) {file.close();throw e;}
  }
  private Media fingerprint(String name) throws Exception {
    MessageDigest digest=MessageDigest.getInstance("SHA-256");long size=0;
    try(InputStream input=open(name)) {
      byte[] buf=new byte[65536];int n;
      while((n=input.read(buf))!=-1) {digest.update(buf,0,n);size+=n;}
    }
    return new Media(hex(digest.digest()),size);
  }
  private static String hex(byte[] b) {
    StringBuilder s=new StringBuilder(b.length*2);
    for(byte n:b) s.append(String.format(Locale.ROOT,"%02x",n&255));
    return s.toString();
  }
  public void erase() throws IOException { if (!deleteChildren(root)) throw new IOException("Не удалось удалить временные данные экспорта"); }
  private static boolean deleteChildren(File dir) {
    File[] list=dir.listFiles(); boolean ok=true;
    if(list!=null) for(File f:list) {if(f.isDirectory())ok &=deleteChildren(f); else ok &=f.delete();}
    return dir.delete() && ok;
  }
  @Override public void close() { Arrays.fill(key,(byte)0); }
}
