package org.vault.exporter;

import java.io.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public final class ArchiveVerifier {
  public static int verify(InputStream input, char[] password) throws Exception {
    ChunkedVault.Decrypt decrypted = new ChunkedVault.Decrypt(input, password);
    int entries = 0;
    boolean manifestSeen = false;
    try (ZipInputStream zip = new ZipInputStream(decrypted)) {
      ZipEntry entry;
      byte[] buf = new byte[65536];
      while ((entry = zip.getNextEntry()) != null) {
        ArchiveWriter.validate(entry.getName());
        if (++entries > 20000000) throw new IOException("Слишком много элементов");
        if ("manifest.json".equals(entry.getName())) {
          if(manifestSeen) throw new IOException("Повторный манифест");
          manifestSeen = true;
          ByteArrayOutputStream manifest=new ByteArrayOutputStream();
          int n;
          while((n=zip.read(buf))!=-1) {
            if(manifest.size()+n>1024*1024) throw new IOException("Манифест слишком большой");
            manifest.write(buf,0,n);
          }
          String content = manifest.toString("UTF-8");
          if (!content.matches("(?s).*\"schema\"\\s*:\\s*\"tg-vault-v1\".*"))
            throw new IOException("Неизвестная схема архива");
        } else {
          while (zip.read(buf) != -1) { /* exhaust and verify ZIP CRC */ }
        }
        zip.closeEntry();
      }
      // ZipInputStream may stop at the central directory; force reading final AEAD chunk/tag.
      while (decrypted.read(buf) != -1) { /* authenticate the encrypted suffix */ }
    }
    if (!manifestSeen) throw new IOException("Экспорт прерван: отсутствует manifest.json");
    return entries;
  }
}
